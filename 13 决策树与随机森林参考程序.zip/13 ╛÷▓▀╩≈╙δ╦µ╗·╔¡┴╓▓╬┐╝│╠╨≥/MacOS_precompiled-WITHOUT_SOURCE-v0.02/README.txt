Thanksa lot to David L. Jones for the Precompiled Mac Binaries and instructions.


Compile on own: Either compile via the .m files provided in this folder and the instructions
in the compiler_settings.txt

Or use the precompiled files: 
Download the source code from the site.
Copy the precompiled mex files (in this zip file) for 32/64 bit into the RF_Class_C and
RF_Reg_C folders
